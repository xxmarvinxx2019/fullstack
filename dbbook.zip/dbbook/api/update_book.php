<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

$data = json_decode(file_get_contents("php://input"));

if (
    isset($data->id)
    && isset($data->title)
    && isset($data->author)
    && isset($data->price)
    && isset($data->stock)
    && is_numeric($data->id)
    && !empty(trim($data->title))
    && !empty(trim($data->author))
    && !empty(trim($data->price))
    && !empty(trim($data->stock))
) {
    $title = mysqli_real_escape_string($db_conn, trim($data->title));
    $author = mysqli_real_escape_string($db_conn, trim($data->author));
    $price = mysqli_real_escape_string($db_conn, trim($data->price));
    $stock = mysqli_real_escape_string($db_conn, trim($data->stock));
        $updateUser = mysqli_query($db_conn, "UPDATE `books` SET `title`='$title', `author`='$author',`price`='$price',`stock`='$stock' WHERE `id`='$data->id'");
        if ($updateUser) {
            echo json_encode(["success" => 1, "msg" => "User Updated."]);
        } else {
            echo json_encode(["success" => 0, "msg" => "User Not Updated!"]);
        }
} else {
    echo json_encode(["success" => 0, "msg" => "Please fill all the required fields!"]);
}