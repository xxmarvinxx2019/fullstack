import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Routes,Route,Link,Navigate} from 'react-router-dom';
import Navbars from './components/Navbar';
import ListBook from './components/ListBook';
import UpdateBook from './components/UpdateBook';
import CreateBook from './components/CreateBook';
import { List } from '@mui/icons-material';
import {UserContext} from './components/UserContext';
import Login from './components/Login';
import {useContext} from 'react'

function App() {
  const {user} = useContext(UserContext); 
  return (

      <BrowserRouter>
       <Routes>
            { user && <Route path="/" element={<ListBook/>} />
            
             }
            {!user && (
              <>
              <Route path="/login" element={<Login/>} />
              </>
            )}
            <Route path="*" element={<Navigate to={user ? '/':'/login'} />} />
            <Route path="/edit/:id" element={<UpdateBook/>}/>
            <Route path="/create" element={<CreateBook/>}/>
          </Routes>
        <Navbars/>
      </BrowserRouter>
  );
}

export default App;
