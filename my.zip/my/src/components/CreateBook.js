import {Container,Box,TextField,Paper,Button,Alert,AlertTitle,Collapse} from '@mui/material'
import {useState} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


export default function CreateBook() {
    const [input,setInputs] = useState({});
    const [open,setOpen] = useState(false)
    const history = useNavigate();
    const handleInput = (events) => {
        const name = events.target.name;
        const value = events.target.value;
        setInputs(values => ({...values,[name]:value}));
    }
    const handleSubmit = () => {
        axios.post('http://localhost/dbbook/api/create_book.php',input).then(function (response) {
            console.log(response.data.success);
            if(response.data.success == 1){
                setOpen(true)
                if(input != ''){
                    setTimeout(() => {
                        setOpen(false);
                        history('/')
                      }, 3000);
                }
                /*history('/')*/
                 
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    }
    return (
        <Container>
            <Box mt={3}>
            <Collapse in={open}>
                <Alert severity="success">
                    <AlertTitle>Success</AlertTitle>
                        Book Added <strong>check it out!</strong>
                </Alert>
            </Collapse>
            </Box>
            <Box component={Paper} p={2} spacing={2} mt={4}
                sx={{
                width: 500,
                maxWidth: '100%',
                display: 'grid',
              }}
            >
                <Box mt={1}>
                    <Box sx={{ fontSize: 30}}>Create New Book</Box>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Title" name="title" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Author" name="author" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Pricing" name="price" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Stock" name="stock" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <Button variant="contained" onClick={handleSubmit}>Submit</Button>
                </Box>
            </Box>
        </Container>
    )
}