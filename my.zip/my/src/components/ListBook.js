import * as React from  'react';
import {Container,Table,TableBody,TableCell,TableContainer,
    TableHead,TableRow,Paper,Box,Button,IconButton} from '@mui/material';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import DeleteIcon from '@mui/icons-material/Delete';
import { alpha, styled } from '@mui/material/styles';
import { makeStyles } from '@mui/material/styles';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';

export default function ListBook() {
  const [books,setBooks] = useState([])
  useEffect(() => {
    getBooks();
  },[]);
  const del = (id) => (event) => {
    event.preventDefault();
    console.log(id)
    axios.post('http://localhost/dbbook/api/delete_book.php',id).then(function (response) {
            console.log(response.data.success);
            if(response.data.success == 1){
              console.log(response.data.success);
              getBooks();
            }
        })
        .catch(function (error) {
            console.log(error);
        });
      
  }
  function getBooks(){
    axios.get('http://localhost/dbbook/api/get_book.php').then(function (response) {
      console.log(response.data.users);

      setBooks(response.data.users)
    })
  }

    return (
        <Container>
            <Box mt={4} p={1} spacing={2}>
                <Button component={Link} to="/create" variant="contained" sx={{ textTransform: 'lowercase' }}>Create</Button>
            </Box>
            <Box sx={{ mt: 4, p: 1 }}>
              <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell>No.</TableCell>
                      <TableCell>Title</TableCell>
                      <TableCell align="left">Author</TableCell>
                      <TableCell align="left">Price</TableCell>
                      <TableCell align="left">Stock</TableCell>
                      <TableCell align="left">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    
                    {
                      books ?
                    books.map((book,key) => (
                      <TableRow
                        key={key}
                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                      >
                        <TableCell component="th" scope="row">
                          {key + 1}
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {book.title}
                        </TableCell>
                        <TableCell align="left">{book.author}</TableCell>
                        <TableCell align="left">{book.price}</TableCell>
                        <TableCell align="left">{book.stock}</TableCell>
                        <TableCell align="left">
                          <Button component={Link} to={`/edit/${book.id}`}>
                          <IconButton color="primary" aria-label="upload picture" component="span">
                            <ModeEditIcon />
                          </IconButton> 
                          </Button>
                          <Button onClick={del(book.id)}>
                          <IconButton color="error" aria-label="upload picture" component="span">
                            <DeleteIcon />
                          </IconButton>
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                    ):
                    <TableRow>
                    <TableCell>No Data found</TableCell>
                    </TableRow>
                  }
                    
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
        </Container>
    )
}