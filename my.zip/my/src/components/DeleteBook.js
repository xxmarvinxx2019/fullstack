export default function DeleteBook() {
    return (
        <h1>Delete</h1>
    )
}