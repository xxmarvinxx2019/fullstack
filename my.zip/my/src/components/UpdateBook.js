import {Container,Box,TextField,Paper,Button,Alert,AlertTitle,Collapse} from '@mui/material';
import {useState,useEffect} from 'react';
import axios from 'axios';
import { useNavigate,useParams} from 'react-router-dom';


export default function UpdateBook() {
    const [input,setInputs] = useState({});
    const [books,setBooks] = useState({})
    const [open,setOpen] = useState(false)
    const history = useNavigate();
    const params = useParams();

    console.log(params.id);
    const [input1,setInputs1] = useState({id:1});
    const handleInput = (events) => {
        const name = events.target.name;
        const value = events.target.value;
        setBooks(values => ({...values,[name]:value}));
    }

    useEffect(() => {
        getBooks();
    },[]);
    const sub = (event) => {
        event.preventDefault();
        axios.post('http://localhost/dbbook/api/update_book.php',books).then(function (response) {
            console.log(response);
            if(response.data.success == 1){
                setOpen(true)

                if(input != ''){
                    setTimeout(() => {
                        setOpen(false);
                        history('/')
                      }, 3000);
                }
                /*history('/')*/
                 
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    }
    function getBooks(){
        axios.get(`http://localhost/dbbook/api/get_single_books.php/${params.id}`).then(function (response) {
          console.log(response.data.users[0]);
          setBooks(response.data.users[0])
        })
    }
    return (
        <Container>
            <Box component={Paper} p={2} spacing={2} mt={4}
                sx={{
                width: 500,
                maxWidth: '100%',
                display: 'grid',
              }}
            >
                <Box mt={3}>
                    <Collapse in={open}>
                        <Alert severity="success">
                            <AlertTitle>Success</AlertTitle>
                            Book Update <strong>check it out!</strong>
                        </Alert>
                    </Collapse>
                </Box>
                <Box mt={1}>
                    <Box sx={{ fontSize: 30}}>Update Book</Box>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={books.title} defaultValue="sad" label="Title" name="title" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={books.author} defaultValue="sad" label="Author" name="author" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={books.price} defaultValue="sad" label="Pricing" name="price" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={books.stock} defaultValue="sad" label="Stock" name="stock" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <Button variant="contained" onClick={sub}>Update</Button>
                </Box>
            </Box>
        </Container>
    )
}