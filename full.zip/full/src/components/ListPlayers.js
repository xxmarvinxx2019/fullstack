import * as React from  'react';
import { useState,useEffect } from "react";
import {Container,Table,TableBody,TableCell,TableContainer,
    TableHead,TableRow,Paper,Box,Button,IconButton} from '@mui/material';
import { styled } from '@mui/material/styles';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import DeleteIcon from '@mui/icons-material/Delete';
import AttachmentIcon from '@mui/icons-material/Attachment';
import AddBoxIcon from '@mui/icons-material/AddBox';
import {Link} from 'react-router-dom';
import axios from 'axios';
const Input = styled('input')({
    display: 'none',
});
  
export default function ListPlayers () {
    const [players,setPlayers] = useState([])
    const [file, setFile] = useState();

    const fileReader = new FileReader();
    const [array, setArray] = useState([]);

    useEffect(() => {
      getPlayers();
    },[]);
    function getPlayers(){
      axios.get('http://localhost/dbplayers/api/get_players.php').then(function (response) {
        console.log(response.data.users);
  
        setPlayers(response.data.users)
      })
    }
    const handleOnChange = (e) => {
        setFile(e.target.files[0]);
        console.log(e.target.files[0])
    };
    const csvFileToArray = string => {
        const csvHeader = string.slice(0, string.indexOf("\n")).split(",");
        const csvRows = string.slice(string.indexOf("\n") + 1).split("\n");
    
        const array = csvRows.map(i => {
          const values = i.split(",");
          const obj = csvHeader.reduce((object, header, index) => {
            object[header] = values[index];
            return object;
          }, {});
          return obj;
        });
    
        setArray(array);
      };
      const handleOnSubmit = (e) => {
        e.preventDefault();
    
        if (file) {
          fileReader.onload = function (event) {
            const text = event.target.result;
            csvFileToArray(text);
            console.log(text)
          };
    
          fileReader.readAsText(file);
        }
      };
      const headerKeys = Object.keys(Object.assign({}, ...array));


    return(
        <Container>
            <Box mt={4} p={1} spacing={2}>
            {/*<label htmlFor="contained-button-file">
                <Input accept=".xlsx, .xls, .csv" id="contained-button-file" multiple type="file" onChange={handleOnChange}/>
                <Button startIcon={<AttachmentIcon />} component="span" variant="contained" sx={{ textTransform: 'Capitalize' }}>upload</Button>
            </label>
            {file ? <p>{file.name}</p> : ''}
              <button
                onClick={(e) => {
                  handleOnSubmit(e);
                }}
              >
                IMPORT CSV
              </button>*/}
              <Button startIcon={<AddBoxIcon/>} component={Link} to="/create" variant="contained">Create</Button>
            </Box>
            <Box sx={{ mt: 4, p: 1 }}>
              <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell>No.</TableCell>
                      <TableCell>Full Name</TableCell>
                      <TableCell align="left">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    
                  {
                      players ?
                      players.map((players,key) => (
                      <TableRow
                        key={key}
                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                      >
                        <TableCell component="th" scope="row">
                          {key + 1}
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {players.first_name} {players.second_name}
                        </TableCell>
                        <TableCell align="left">
                          <Button component={Link} to={`/edit/${players.id}`}>
                          <IconButton color="primary" aria-label="upload picture" component="span">
                            <ModeEditIcon />
                          </IconButton> 
                          </Button>
                          <Button>
                          <IconButton color="error" aria-label="upload picture" component="span">
                            <DeleteIcon />
                          </IconButton>
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                    ):
                    <TableRow>
                    <TableCell>No Data found</TableCell>
                    </TableRow>
                  }
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
        </Container>
    )
}