import {Container,Box,TextField,Paper,Button,Alert,AlertTitle,Collapse} from '@mui/material'
import {useState} from 'react';
import axios from 'axios';
import { useNavigate,Link } from 'react-router-dom';


export default function UpdatePlayers() {
    const [input,setInputs] = useState({});
    const [open,setOpen] = useState(false)
    const history = useNavigate();
    const params = useParams();

    console.log(params.id);
    const [input1,setInputs1] = useState({id:1});
    const handleInput = (events) => {
        const name = events.target.name;
        const value = events.target.value;
        setBooks(values => ({...values,[name]:value}));
    }

    useEffect(() => {
        getBooks();
    },[]);
    const sub = (event) => {
        event.preventDefault();
        axios.post('http://localhost/dbbook/api/update_book.php',books).then(function (response) {
            console.log(response);
            if(response.data.success == 1){
                setOpen(true)

                if(input != ''){
                    setTimeout(() => {
                        setOpen(false);
                        history('/')
                      }, 3000);
                }
                /*history('/')*/
                 
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    }
    function getBooks(){
        axios.get(`http://localhost/dbbook/api/get_single_books.php/${params.id}`).then(function (response) {
          console.log(response.data.users[0]);
          setBooks(response.data.users[0])
        })
    }
    return (
        <Container>
            <Box mt={3}>
            <Collapse in={open}>
                <Alert severity="success">
                    <AlertTitle>Success</AlertTitle>
                        Book Added <strong>check it out!</strong>
                </Alert>
            </Collapse>
            </Box>
            <Box component={Paper} p={2} spacing={2} mt={4}
                sx={{
                width: 500,
                maxWidth: '100%',
                display: 'grid',
              }}
            >
                <Box mt={1}>
                    <Box sx={{ fontSize: 30}}>Create New Players</Box>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="First Name" name="first_name" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Last Name" name="second_name" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Form" name="form" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField id="outlined-basic" label="Total points" name="total_points" variant="outlined" onChange={handleInput}/>
                    <TextField id="outlined-basic" label="Influence" name="influence" variant="outlined" onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField id="outlined-basic" label="Creativity" name="creativity" variant="outlined"  onChange={handleInput}/>
                    <TextField id="outlined-basic" ml={2} label="Threat" name="threat" variant="outlined"  onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="ICT Index" name="ict_index" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }} >
                    <Button variant="contained" onClick={handleSubmit}>Submit</Button>
                    <Button variant="contained" component={Link} to="/" color="success">Cancel</Button>
                </Box>
            </Box>
        </Container>
    )
}