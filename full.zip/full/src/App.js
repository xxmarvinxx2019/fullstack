import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import ListPlayers from './components/ListPlayers';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import CreatePlayer from './components/CreatePlayer';

function App() {
  return (
    <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<ListPlayers/>} />
        <Route path="/create" element={<CreatePlayer/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
